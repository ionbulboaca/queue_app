<script type="text/javascript">
	var base_url = <?php echo json_encode(BASE_URL); ?>;
</script>
<script type="text/javascript" language="javascript" src="assets/js/my_js.js"></script>
</body>
</html>